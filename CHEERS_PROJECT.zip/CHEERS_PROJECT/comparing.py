from main import valuepassfromscratch

from main_second import valuepassfromlibrary

print (valuepassfromlibrary)
print (valuepassfromscratch)